<?php

namespace App\Controller;

use App\Entity\App\Repository\AlimentRepository;
use App\Entity\GroupeAliment;
use App\Form\GroupeAlimentForm;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

#[Route('/groupe/aliment')]
final class GroupeAlimentController extends AbstractController
{
    #[Route(name: 'app_groupe_aliment_index', methods: ['GET'])]
    public function index(AlimentRepository $alimentRepository): Response
    {
        return $this->render('groupe_aliment/index.html.twig', [
            'groupe_aliments' => $alimentRepository->findAll(),
        ]);
    }

    #[Route('/new', name: 'app_groupe_aliment_new', methods: ['GET', 'POST'])]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $groupeAliment = new GroupeAliment();
        $form = $this->createForm(GroupeAlimentForm::class, $groupeAliment);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->persist($groupeAliment);
            $entityManager->flush();

            return $this->redirectToRoute('app_groupe_aliment_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('groupe_aliment/new.html.twig', [
            'groupe_aliment' => $groupeAliment,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_groupe_aliment_show', methods: ['GET'])]
    public function show(GroupeAliment $groupeAliment): Response
    {
        return $this->render('groupe_aliment/show.html.twig', [
            'groupe_aliment' => $groupeAliment,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_groupe_aliment_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, GroupeAliment $groupeAliment, EntityManagerInterface $entityManager): Response
    {
        $form = $this->createForm(GroupeAlimentForm::class, $groupeAliment);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager->flush();

            return $this->redirectToRoute('app_groupe_aliment_index', [], Response::HTTP_SEE_OTHER);
        }

        return $this->render('groupe_aliment/edit.html.twig', [
            'groupe_aliment' => $groupeAliment,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_groupe_aliment_delete', methods: ['POST'])]
    public function delete(Request $request, GroupeAliment $groupeAliment, EntityManagerInterface $entityManager): Response
    {
        if ($this->isCsrfTokenValid('delete'.$groupeAliment->getId(), $request->getPayload()->getString('_token'))) {
            $entityManager->remove($groupeAliment);
            $entityManager->flush();
        }

        return $this->redirectToRoute('app_groupe_aliment_index', [], Response::HTTP_SEE_OTHER);
    }
}
