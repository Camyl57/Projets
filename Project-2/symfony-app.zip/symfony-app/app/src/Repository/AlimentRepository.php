<?php
// src/Repository/AlimentRepository.php

namespace App\Repository;

use App\Entity\Aliment;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Aliment>
 */
class AlimentRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Aliment::class);
    }

    // Ici tu peux ajouter tes méthodes personnalisées, par exemple :
    // public function findByPrixGreaterThan(float $min): array { ... }
}
