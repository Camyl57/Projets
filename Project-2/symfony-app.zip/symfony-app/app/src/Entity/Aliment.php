<?php

namespace App\Entity;

use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\ORM\Mapping as ORM;


#[ORM\Entity]
class Aliment{

    /* L'ID pour identifier l'aliment */
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;
    /*------------------------------------------------*/


    /* Le libellé de l'aliment */
    #[ORM\Column(length: 100)]
    #[Assert\NotBlank(message: 'Le libellé est obligatoire')]
    #[Assert\Length(
        min: 2,
        max: 100,
        minMessage: 'Le libellé doit comporter au moins {{ limit }} caractères',
        maxMessage: 'Le libellé ne peut pas dépasser {{ limit }} caractères',
    )]
    private ?string $libelle = null;
    /*------------------------------------------------*/


    /* Le prix de l'aliment */
    #[Assert\NotBlank(message: 'Le prix est obligatoire')]
    #[Assert\Type(
        type: 'float',
        message: 'Le prix doit être un nombre décimal.',
    )]
    #[Assert\GreaterThanOrEqual(
        value: 0,
        message: 'Le prix doit être supérieur ou égal à 0.',
    )]
    #[ORM\Column(type: 'float')]
    private ?float $prix = null;
    /*------------------------------------------------*/

    /* Le GroupeAliment auquel appartient l'aliment */
    #[ORM\ManyToOne(inversedBy: 'aliments')]
    #[ORM\JoinColumn(nullable: false)]
    private ?GroupeAliment $groupe = null;
    /*------------------------------------------------*/

    public function getGroupe(): ?GroupeAliment
    {
        return $this->groupe;
    }
    public function setGroupe(?GroupeAliment $groupe): self
    {
        $this->groupe = $groupe;

        return $this;
    }

    


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }

    public function getPrix(): ?float
    {
        return $this->prix;
    }

    public function setPrix(float $prix): self
    {
        $this->prix = $prix;

        return $this;
    }


}