<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Entity\Utilisateur;

#[ORM\Entity]
class GroupeUtilisateur
{
    /* L'ID pour identifier le groupe d'utilisateurs */
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type:"integer")]
    private ?int $id = null;
    //------------------------------------------------


    /* Le nom du groupe d'utilisateurs */
    #[ORM\Column(length: 100)]
    private ?string $nom = null;
    //------------------------------------------------

    /* Le GroupeUtilisateur contient plusieurs utilisateurs */
    #[ORM\OneToMany(mappedBy: 'groupeUtilisateur', targetEntity: Utilisateur::class)]
    private Collection $utilisateurs;
    //------------------------------------------------

    
    public function __construct()
    {
        $this->utilisateurs = new ArrayCollection();
    }

    

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;
        return $this;
    }

    /**
     * @return Collection|Utilisateur[]
     */
    public function getUtilisateurs(): Collection
    {
        return $this->utilisateurs;
    }

    public function addUtilisateur(Utilisateur $utilisateur): self
    {
        if (!$this->utilisateurs->contains($utilisateur)) {
            $this->utilisateurs[] = $utilisateur;
            $utilisateur->setGroupeUtilisateur($this);
        }
        return $this;
    }

    public function removeUtilisateur(Utilisateur $utilisateur): self
    {
        if ($this->utilisateurs->removeElement($utilisateur)) {
            if ($utilisateur->getGroupeUtilisateur() === $this) {
                $utilisateur->setGroupeUtilisateur(null);
            }
        }
        return $this;
    }
}
