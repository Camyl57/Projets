<?php   

namespace App\Entity;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Entity\Aliment;



#[ORM\Entity(repositoryClass: App\Repository\AlimentRepository::class)]
class GroupeAliment
{

/* L'ID pour identifier le groupe d'aliments */
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;
/*----------------------------------------------*/

/* Le libellé du groupe d'aliments */
    #[ORM\Column(length: 100)]
    #[Assert\NotBlank(message: 'Le libellé est obligatoire')]
    #[Assert\Length(
        min: 2,
        max: 100,
        minMessage: 'Le libellé doit comporter au moins {{ limit }} caractères',
        maxMessage: 'Le libellé ne peut pas dépasser {{ limit }} caractères',
    )]
    private ?string $libelle = null;
/*------------------------------------------------*/


/*  Le GroupeAliments contient plusieurs aliments  */
    #[ORM\OneToMany(mappedBy: 'groupe', targetEntity: Aliment::class)]
    private Collection $aliments;
/*------------------------------------------------*/

    public function __construct()
    {
        $this->aliments = new ArrayCollection();
    }


    public function addAliment(Aliment $aliment): self
    {
        if (!$this->aliments->contains($aliment)) {
            $this->aliments[] = $aliment;
            $aliment->setGroupe($this);
        }

        return $this;
    }


    public function removeAliment(Aliment $aliment): self
    {
        if ($this->aliments->removeElement($aliment)) {
            if ($aliment->getGroupe() === $this) {
                $aliment->setGroupe(null);
            }
        }

        return $this;
    }

    public function getAliments(): Collection
    {
        return $this->aliments;
    }

    public function setAliments(Collection $aliments): self
    {
        $this->aliments = $aliments;

        foreach ($aliments as $aliment) {
            $aliment->setGroupe($this);
        }

        return $this;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }


}