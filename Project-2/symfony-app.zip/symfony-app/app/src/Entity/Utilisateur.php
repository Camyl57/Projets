<?php 

namespace App\Entity;
use Symfony\Component\Validator\Constraints as Assert;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Entity\Stock;

#[ORM\Entity(repositoryClass: App\Repository\UtilisateurRepository::class)]
class Utilisateur{

    /* L'ID pour identifier l'utilisateur */
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;
    /*------------------------------------------------*/

    /* Le nom de l'utilisateur */
    #[ORM\Column(length: 100)]
    #[Assert\NotBlank(message: 'Le nom est obligatoire')]
    #[Assert\Length(
        min: 2,
        max: 100,
        minMessage: 'Le nom doit comporter au moins {{ limit }} caractères',
        maxMessage: 'Le nom ne peut pas dépasser {{ limit }} caractères',
    )]
    private ?string $nom = null;
    /*------------------------------------------------*/

    /* Le prénom de l'utilisateur */
    #[ORM\Column(length: 100)]
    #[Assert\NotBlank(message: 'Le prénom est obligatoire')]
    #[Assert\Length(
        min: 2,
        max: 100,
        minMessage: 'Le prénom doit comporter au moins {{ limit }} caractères',
        maxMessage: 'Le prénom ne peut pas dépasser {{ limit }} caractères',
    )]
    private ?string $prenom = null;
    /*------------------------------------------------*/

    /* L'email de l'utilisateur */
    #[ORM\Column(length: 180, unique: true)]
    #[Assert\NotBlank(message: 'L\'email est obligatoire')]
    #[Assert\Email(
        message: 'L\'email "{{ value }}" n\'est pas un email valide.',
    )]
    private ?string $email = null;
    /*------------------------------------------------*/

    /* Le mot de passe de l'utilisateur */
    #[ORM\Column]
    #[Assert\NotBlank(message: 'Le mot de passe est obligatoire')]
    #[Assert\Length(
        min: 6,
        minMessage: 'Le mot de passe doit comporter au moins {{ limit }} caractères',
    )]
    //On va vérifier la validité du mot de passe avec regex
    #[Assert\Regex(
    pattern: '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$/',
    message: 'Le mot de passe doit contenir au moins une majuscule, une minuscule, un chiffre et un caractère spécial.'
    )]
    private ?string $password = null;
    /*------------------------------------------------*/

    /* La relation avec stock */
    #[ORM\OneToMany(mappedBy: 'utilisateur', targetEntity: Stock::class, orphanRemoval: true)]
    private Collection $stocks;
    /*------------------------------------------------*/

    /* La relation avec GroupeUtilisateur */
    #[ORM\ManyToOne(inversedBy: 'utilisateurs')]
    #[ORM\JoinColumn(nullable: true)] 
    private ?GroupeUtilisateur $groupeUtilisateur = null;
    /*------------------------------------------------*/

    

    public function __construct()
    {
        $this->stocks = new ArrayCollection();
    }
    
    public function getGroupeUtilisateur(): ?GroupeUtilisateur
    {
        return $this->groupeUtilisateur;
    }

    public function setGroupeUtilisateur(?GroupeUtilisateur $groupeUtilisateur): self
    {
        $this->groupeUtilisateur = $groupeUtilisateur;
        return $this;
    }

    public function getId(): ?int
    {
        return $this->id;
    }
    public function getNom(): ?string
    {
        return $this->nom;
    }
    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }
    public function getPrenom(): ?string
    {
        return $this->prenom;
    }
    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }
    public function getEmail(): ?string
    {
        return $this->email;
    }
    public function setEmail(string $email): self
    {
        $this->email = $email;

        return $this;
    }
    public function getPassword(): ?string
    {
        return $this->password;
    }
    public function setPassword(string $password): self
    {
        $this->password = $password;

        return $this;
    }
    public function getStocks(): Collection
    {
        return $this->stocks;
    }
    public function addStock(Stock $stock): self
    {
        if (!$this->stocks->contains($stock)) {
            $this->stocks[] = $stock;
            $stock->setUtilisateur($this);
        }

        return $this;
    }

    public function removeStock(Stock $stock): self
    {
        if ($this->stocks->removeElement($stock)) {
            if ($stock->getUtilisateur() === $this) {
                $stock->setUtilisateur(null);
            }
        }

        return $this;
    }

}